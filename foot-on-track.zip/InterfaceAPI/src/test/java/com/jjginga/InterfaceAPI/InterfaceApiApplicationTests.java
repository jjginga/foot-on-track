package com.jjginga.InterfaceAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterfaceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
