package com.jjginga.TrainingPlan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainningPlanApplicationTests {

	@Test
	void contextLoads() {
	}

}
