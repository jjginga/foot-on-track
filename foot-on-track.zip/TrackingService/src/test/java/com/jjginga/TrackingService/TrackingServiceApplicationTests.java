package com.jjginga.TrackingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
